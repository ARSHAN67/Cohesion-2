# Design System Strategy: The Digital Atelier

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Digital Atelier."** It represents a space where the craftsmanship of high-fashion editorial meets the precision of advanced technology. We are moving away from the "template" look of standard SaaS platforms toward a bespoke, curated experience. 

The system achieves its premium feel through **Intentional Asymmetry** and **Tonal Depth**. By utilizing wide margins, overlapping elements, and a high-contrast typography scale, we create a layout that breathes. This is not a rigid grid; it is a composition. We treat the screen as a physical space where light, glass, and paper interact to guide the user’s eye with quiet authority.

---

## 2. Colors: The High-Fashion Palette
Our color strategy relies on a foundation of sophisticated neutrals punctuated by "Tech-Blue" and "Fashion-Lavender."

### The "No-Line" Rule
**Standard 1px borders are strictly prohibited for sectioning.** To define boundaries, you must use background color shifts (e.g., placing a `surface-container-low` section against a `surface` background). The eye should perceive change through tonal transitions, not structural lines.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. Use the surface tiers to create "nested" depth:
- **Level 0 (Base):** `surface` (#f8f9fa) — The canvas.
- **Level 1 (Subtle Inset):** `surface-container-low` (#f3f4f5) — For secondary content areas.
- **Level 2 (Raised):** `surface-container-lowest` (#ffffff) — For primary interactive cards and modules to create a "pop" against the grey.
- **Level 3 (Overlay):** `surface-container-highest` (#e1e3e4) — For navigation or utility sidebars.

### The Glass & Gradient Rule
To achieve the "High-Tech" vibe, utilize **Glassmorphism** for floating elements (Modals, Tooltips, Navigation Bars). Use a semi-transparent `surface` color with a `backdrop-blur` of 20px–40px. 

**Signature Texture:** For primary CTAs or high-impact hero backgrounds, apply a subtle linear gradient from `primary` (#4a47d2) to `primary-container` (#6462ec) at a 135-degree angle. This adds a "visual soul" that flat color lacks.

---

## 3. Typography: Editorial Authority
The type system pairs the intellectual elegance of a serif with the functional clarity of a geometric sans-serif.

*   **Display & Headlines (`notoSerif`):** These are our "statement" pieces. Use `display-lg` (3.5rem) with generous letter-spacing to command attention. This serif choice signals heritage and luxury.
*   **Body & Labels (`manrope`):** For all functional data, we use Manrope. Its clean, high-tech structure ensures readability in dense software environments.
*   **The Contrast Rule:** Always pair a `headline-lg` with a `body-md` in close proximity. The dramatic jump in scale creates the "Editorial" look common in high-fashion magazines.

---

## 4. Elevation & Depth: Tonal Layering
We do not use shadows to simulate height; we use light and opacity.

*   **The Layering Principle:** Depth is achieved by stacking. A `surface-container-lowest` (#ffffff) card sitting on a `surface-container-low` (#f3f4f5) background provides a natural, soft lift without a single pixel of shadow.
*   **Ambient Shadows:** If a floating effect is required (e.g., a dropdown), use an extra-diffused shadow: `blur: 40px`, `y: 10px`, `opacity: 6%`. The shadow color must be a tinted version of `on-surface` (#191c1d), never pure black.
*   **The "Ghost Border" Fallback:** If a border is required for accessibility, use the `outline-variant` (#c9c4d8) at **20% opacity**. 100% opaque borders are forbidden.
*   **Glassmorphism:** Use `surface_variant` at 60% opacity with a heavy blur for floating navigation. This allows the sophisticated lavender and blue accents of the background to bleed through, softening the interface.

---

## 5. Components: Crafted Primitives

### Buttons
- **Primary:** Gradient fill (`primary` to `primary-container`), white text, `lg` (0.5rem) roundedness.
- **Secondary:** `secondary-fixed` (#ebddff) background with `on-secondary-fixed` (#22123f) text. No border.
- **Tertiary:** Transparent background, `primary` text, with a subtle underline on hover.

### Cards & Lists
**Strict Rule:** No divider lines. Separate list items using 16px–24px of vertical white space or a very subtle background toggle between `surface-container-low` and `surface-container-lowest`. 

### Input Fields
- **Background:** `surface-container-high` (#e7e8e9).
- **Active State:** Change background to `surface-container-lowest` (#ffffff) and apply a 1px "Ghost Border" using `primary` at 30% opacity.
- **Shape:** `md` (0.375rem) roundedness.

### Signature Component: The "Editorial Chip"
Use `tertiary-fixed` (#cde5ff) with `on-tertiary-fixed` (#001d32) for tags. They should have `full` roundedness and use `label-md` typography to look like high-fashion clothing tags.

---

## 6. Do’s and Don’ts

### Do:
- **Embrace White Space:** Give elements twice as much room as you think they need.
- **Nesting Surfaces:** Use `surface-container` tiers to group related items instead of boxes.
- **Use Serifs for Impact:** Reserve `notoSerif` for moments of inspiration or key section headers.

### Don’t:
- **No Heavy Borders:** Never use a high-contrast 100% opaque border. It breaks the "glass" illusion.
- **No Pure Black:** Use `on-surface` (#191c1d) for text to maintain the soft, premium feel.
- **Don’t Over-Shadow:** If you can achieve depth with color shifts, do not use a shadow. Shadows are for floating elements only.
- **Avoid Symmetry:** When designing hero sections, try offsetting the text to the left and the 3D/Glass element to the right with overlapping margins.